$mirrors = {
  'Africa' => {
    'Morocco' => {
      'https://mirror.marwan.ma/ctan/' => 1,
    },
    'South Africa' => {
      'http://ftp.sun.ac.za/ftp/CTAN/' => 1,
      'https://mirror.ufs.ac.za/ctan/' => 1,
    },
  },
  'Asia' => {
    'China' => {
      'https://mirror.nyist.edu.cn/CTAN/' => 1,
      'https://mirrors.aliyun.com/CTAN/' => 1,
      'https://mirrors.bfsu.edu.cn/CTAN/' => 1,
      'https://mirrors.cloud.tencent.com/CTAN/' => 1,
      'https://mirrors.cqu.edu.cn/CTAN/' => 1,
      'https://mirrors.jlu.edu.cn/CTAN/' => 1,
      'https://mirrors.nju.edu.cn/CTAN/' => 1,
      'https://mirrors.pku.edu.cn/ctan/' => 1,
      'https://mirrors.sjtug.sjtu.edu.cn/ctan/' => 1,
      'https://mirrors.sustech.edu.cn/CTAN/' => 1,
      'https://mirrors.tuna.tsinghua.edu.cn/CTAN/' => 1,
      'https://mirrors.ustc.edu.cn/CTAN/' => 1,
    },
    'Hong Kong' => {
      'https://mirror-hk.koddos.net/CTAN/' => 1,
    },
    'India' => {
      'https://in.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.niser.ac.in/ctan/' => 1,
    },
    'Indonesia' => {
      'http://repo.ugm.ac.id/ctan/' => 1,
      'https://mirror.unpad.ac.id/ctan/' => 1,
    },
    'Iran' => {
      'http://ctan.asis.ai/' => 1,
      'https://ctan.yazd.ac.ir/' => 1,
    },
    'Japan' => {
      'http://ring.airnet.ne.jp/archives/text/CTAN/' => 1,
      'https://ftp.jaist.ac.jp/pub/CTAN/' => 1,
      'https://ftp.kddilabs.jp/CTAN/' => 1,
      'https://ftp.yz.yamagata-u.ac.jp/pub/CTAN/' => 1,
      'https://jp.mirrors.cicku.me/ctan/' => 1,
    },
    'Korea' => {
      'http://ftp.ktug.org/tex-archive/' => 1,
      'https://ftp.kaist.ac.kr/tex-archive/' => 1,
      'https://kr.mirrors.cicku.me/ctan/' => 1,
      'https://lab.uklee.pe.kr/tex-archive/' => 1,
      'https://mirror.kakao.com/CTAN/' => 1,
    },
    'Singapore' => {
      'https://sg.mirrors.cicku.me/ctan/' => 1,
    },
    'Taiwan' => {
      'https://ctan.mirror.twds.com.tw/tex-archive/' => 1,
    },
    'Thailand' => {
      'https://mirror.kku.ac.th/CTAN/' => 1,
    },
  },
  'Europe' => {
    'Austria' => {
      'https://mirror.easyname.at/ctan/' => 1,
      'https://mirror.kumi.systems/ctan/' => 1,
    },
    'Belarus' => {
      'https://mirror.datacenter.by/pub/mirrors/CTAN/' => 1,
    },
    'Czech Republic' => {
      'http://ftp.cvut.cz/tex-archive/' => 1,
      'https://mirrors.nic.cz/tex-archive/' => 1,
    },
    'Denmark' => {
      'https://mirrors.dotsrc.org/ctan/' => 1,
    },
    'Finland' => {
      'https://mirror.5i.fi/tex-archive/' => 1,
      'https://www.nic.funet.fi/pub/TeX/CTAN/' => 1,
      'https://www.texlive.info/CTAN/' => 1,
    },
    'France' => {
      'https://ctan.gutenberg-asso.fr/' => 1,
      'https://ctan.mines-albi.fr/' => 1,
      'https://ctan.tetaneutral.net/' => 1,
      'https://distrib-coffee.ipsl.jussieu.fr/pub/mirrors/ctan/' => 1,
      'https://mirror.ibcp.fr/pub/CTAN/' => 1,
      'https://mirrors.ircam.fr/pub/CTAN/' => 1,
      'https://texlive.mycozy.space/' => 1,
    },
    'Germany' => {
      'ftp://ftp.fu-berlin.de/tex/CTAN/' => 1,
      'http://sendinnsky.selfhost.co/tex-archive/' => 1,
      'http://vesta.informatik.rwth-aachen.de/ftp/pub/mirror/ctan/' => 1,
      'https://ctan.ebinger.cc/tex-archive/' => 1,
      'https://ctan.joethei.xyz/' => 1,
      'https://ctan.mc1.root.project-creative.net/' => 1,
      'https://ctan.mirror.norbert-ruehl.de/' => 1,
      'https://ctan.net/' => 1,
      'https://ctan.space-pro.be/tex-archive/' => 1,
      'https://de.mirrors.cicku.me/ctan/' => 1,
      'https://ftp.agdsn.de/pub/mirrors/latex/dante/' => 1,
      'https://ftp.fau.de/ctan/' => 1,
      'https://ftp.gwdg.de/pub/ctan/' => 1,
      'https://ftp.rrze.uni-erlangen.de/ctan/' => 1,
      'https://ftp.rrzn.uni-hannover.de/pub/mirror/tex-archive/' => 1,
      'https://ftp.tu-chemnitz.de/pub/tex/' => 1,
      'https://markov.htwsaar.de/tex-archive/' => 1,
      'https://mirror.clientvps.com/CTAN/' => 1,
      'https://mirror.dogado.de/tex-archive/' => 1,
      'https://mirror.funkfreundelandshut.de/latex/' => 1,
      'https://mirror.physik.tu-berlin.de/pub/CTAN/' => 1,
    },
    'Greece' => {
      'http://ftp.ntua.gr/mirror/ctan/' => 1,
      'https://fosszone.csd.auth.gr/CTAN/' => 1,
      'https://ftp.cc.uoc.gr/mirrors/CTAN/' => 1,
    },
    'Hungary' => {
      'https://mirror.szerverem.hu/ctan/' => 1,
    },
    'Italy' => {
      'https://ctan.mirror.garr.it/mirrors/ctan/' => 1,
    },
    'Netherlands' => {
      'https://ftp.snt.utwente.nl/pub/software/tex/' => 1,
      'https://mirror.koddos.net/CTAN/' => 1,
      'https://mirror.lyrahosting.com/CTAN/' => 1,
    },
    'Norway' => {
      'https://ctan.uib.no/' => 1,
      'https://ftp.fagskolen.gjovik.no/pub/tex-archive/' => 1,
    },
    'Poland' => {
      'https://ctan.gust.org.pl/tex-archive/' => 1,
      'https://polish-mirror.evolution-host.com/ctan/' => 1,
      'https://sunsite.icm.edu.pl/pub/CTAN/' => 1,
    },
    'Portugal' => {
      'https://ftp.eq.uc.pt/software/TeX/' => 1,
      'https://mirrors.up.pt/pub/CTAN/' => 1,
    },
    'Romania' => {
      'https://mirrors.nxthost.com/ctan/' => 1,
    },
    'Russia' => {
      'https://ctan.altspu.ru/' => 1,
      'https://mirror.macomnet.net/pub/CTAN/' => 1,
      'https://mirror.truenetwork.ru/CTAN/' => 1,
    },
    'Spain' => {
      'https://ctan.fisiquimicamente.com/' => 1,
      'https://ctan.javinator9889.com/' => 1,
      'https://osl.ugr.es/CTAN/' => 1,
    },
    'Sweden' => {
      'https://ftp.acc.umu.se/mirror/CTAN/' => 1,
      'https://ftpmirror1.infania.net/mirror/CTAN/' => 1,
    },
    'Switzerland' => {
      'https://mirror.foobar.to/CTAN/' => 1,
      'https://mirror.init7.net/ctan/' => 1,
    },
    'United Kingdom' => {
      'https://anorien.csc.warwick.ac.uk/mirrors/CTAN/' => 1,
      'https://eu.mirrors.cicku.me/ctan/' => 1,
      'https://www-uxsup.csx.cam.ac.uk/pub/tex-archive/' => 1,
    },
  },
  'North America' => {
    'Canada' => {
      'https://ca.mirrors.cicku.me/ctan/' => 1,
      'https://ctan.mirror.globo.tech/' => 1,
      'https://ctan.mirror.rafal.ca/' => 1,
      'https://mirror.csclub.uwaterloo.ca/CTAN/' => 1,
      'https://mirror.its.dal.ca/ctan/' => 1,
      'https://mirror.quantum5.ca/CTAN/' => 1,
      'https://muug.ca/mirror/ctan/' => 1,
    },
    'Costa Rica' => {
      'https://mirrors.ucr.ac.cr/CTAN/' => 1,
    },
    'USA' => {
      'http://mirrors.ibiblio.org/pub/mirrors/CTAN/' => 1,
      'https://ctan.math.illinois.edu/' => 1,
      'https://ctan.math.utah.edu/ctan/tex-archive/' => 1,
      'https://ctan.math.washington.edu/tex-archive/' => 1,
      'https://ctan.mirrors.hoobly.com/' => 1,
      'https://mirror.las.iastate.edu/tex-archive/' => 1,
      'https://mirror.math.princeton.edu/pub/CTAN/' => 1,
      'https://mirror.mwt.me/ctan/' => 1,
      'https://mirrors.mit.edu/CTAN/' => 1,
      'https://mirrors.rit.edu/CTAN/' => 1,
      'https://us.mirrors.cicku.me/ctan/' => 1,
    },
  },
  'Oceania' => {
    'Australia' => {
      'https://au.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.aarnet.edu.au/pub/CTAN/' => 1,
      'https://mirror.cse.unsw.edu.au/pub/CTAN/' => 1,
    },
  },
  'South America' => {
    'Brazil' => {
      'https://linorg.usp.br/CTAN/' => 1,
    },
    'Chile' => {
      'https://ctan.dcc.uchile.cl/' => 1,
    },
  },
};
